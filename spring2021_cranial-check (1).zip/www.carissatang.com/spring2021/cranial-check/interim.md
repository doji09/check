Interim Meeting
======
**Project:** Cranial Check 

**Project Link(s):** [Link to project](https://alyzee.qoom.space/spring2021/cranial-check/index.html)

**Group Member(s):** <!-- add name(s) -->

## Timeline
| Date | Tasks |
| :--- | :--- |
| Jun 9 | <!-- add task --> add css to results.html to display elements nicely |
| Jun 9 | <!-- add task --> Complete CSS for account.html (navbar, table, etc)|
| Jun 16 | <!-- add task --> fix bugs on model (hover/click), add filtering options for account.html if there is time left over |
| Jun 23 | <!-- add task --> Preparing presentation for showcase |
| Jun 30 | Showcase Day! |